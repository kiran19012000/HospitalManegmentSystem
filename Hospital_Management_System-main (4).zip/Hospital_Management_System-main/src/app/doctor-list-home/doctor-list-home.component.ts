import { Component } from '@angular/core';

@Component({
  selector: 'app-doctor-list-home',
  templateUrl: './doctor-list-home.component.html',
  styleUrls: ['./doctor-list-home.component.css']
})
export class DoctorListHomeComponent {

}
